"""
app.py — PyQt6 UI launcher for the Vision Assistant.

Run this instead of main.py. It starts the QApplication, launches all
UI widgets, and runs the agent + voice listener in background threads.

Usage:
    py -3.11 app.py
"""

import sys
import logging
import threading

from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QThread, pyqtSignal, QObject, Qt
from PyQt6.QtGui import QScreen

log = logging.getLogger(__name__)


# ── Agent bridge (runs in background thread, emits Qt signals) ────────────────

class AgentBridge(QObject):
    """
    Wraps the Agent so it can run in a QThread and emit signals
    that the UI widgets can connect to safely (cross-thread).
    """
    on_response   = pyqtSignal(str)          # AI text response
    on_user_query = pyqtSignal(str)          # transcribed voice command
    on_state      = pyqtSignal(str)          # eye state: idle/listening/thinking/speaking
    on_annotate   = pyqtSignal(dict)         # annotation data for overlay
    on_stats      = pyqtSignal(bool)         # True=show stats, False=hide
    on_overlay_dismiss = pyqtSignal()        # dismiss drawing overlay

    def __init__(self, cfg, agent):
        super().__init__()
        self.cfg = cfg
        self.agent = agent

    def run_query(self, user_query: str | None = None):
        """Called from voice listener or hotkey. Runs in worker thread."""
        self.on_state.emit("thinking")
        parsed = self.agent.analyze_screen(user_query=user_query)

        desc = parsed.get("description", "")
        if desc:
            self.on_response.emit(desc)

        # Check for annotation actions
        for action in parsed.get("actions", []):
            if action.get("action") == "annotate":
                self.on_annotate.emit(action)
            elif action.get("action") == "show_stats":
                self.on_stats.emit(True)
            elif action.get("action") == "hide_stats":
                self.on_stats.emit(False)

        self.on_state.emit("idle")


# ── Patched VoiceListener that emits Qt signals ───────────────────────────────

class UIVoiceListener:
    """
    Wraps VoiceListener to intercept transcriptions and emit Qt signals
    before dispatching to the agent.
    """
    def __init__(self, cfg, bridge: AgentBridge):
        from voice.listener import VoiceListener

        self.bridge = bridge

        # Monkey-patch: intercept _transcribe_and_act
        class PatchedListener(VoiceListener):
            def _transcribe_and_act(inner_self):
                import numpy as np
                if not inner_self._frames:
                    return
                audio = np.concatenate(inner_self._frames, axis=0).flatten()
                import time
                t0 = time.monotonic()
                segments, _ = inner_self._whisper.transcribe(
                    audio,
                    language="en",
                    beam_size=3,
                    vad_filter=True,
                    vad_parameters={"min_silence_duration_ms": 300},
                    initial_prompt=(
                        "describe, open, click, scroll, type, search, close, "
                        "maximize, minimize, switch, take screenshot, what is on screen, "
                        "open browser, open terminal, show stats, hide stats, show me"
                    ),
                )
                text = " ".join(s.text.strip() for s in segments).strip()
                log.info(f"Transcribed in {time.monotonic()-t0:.2f}s: '{text}'")
                if not text:
                    return

                # Emit to UI
                bridge.on_user_query.emit(text)
                bridge.on_state.emit("thinking")

                # Run agent in thread
                t = threading.Thread(
                    target=bridge.run_query,
                    args=(text,),
                    daemon=True,
                )
                t.start()

        self._listener = PatchedListener(cfg, bridge.agent)

    def run(self):
        self._listener.run()


# ── Main entry point ──────────────────────────────────────────────────────────

def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s %(name)s — %(message)s",
        datefmt="%H:%M:%S",
    )

    # Load config + agent
    from core.config import Config
    from core.agent import Agent

    cfg = Config.load()
    agent = Agent(cfg)

    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)  # keep alive even if windows close

    screen = app.primaryScreen().availableGeometry()

    # ── Instantiate UI widgets ────────────────────────────────────────────
    from ui.eye_widget import EyeWidget
    from ui.log_panel import LogPanel
    from ui.overlay import DrawingOverlay
    from ui.stats_bar import StatsBar

    eye    = EyeWidget()
    log_panel = LogPanel(screen)
    overlay   = DrawingOverlay(screen)
    stats_bar = StatsBar(screen, model_name=cfg.model)

    overlay.hide()
    stats_bar.hide()

    # ── Wire agent bridge signals to UI ───────────────────────────────────
    bridge = AgentBridge(cfg, agent)

    bridge.on_state.connect(eye.set_state)

    bridge.on_user_query.connect(lambda q: log_panel.add_user_query(q))

    bridge.on_response.connect(lambda r: log_panel.add_ai_response(r))
    bridge.on_response.connect(lambda r: eye.set_state("speaking"))

    bridge.on_annotate.connect(lambda data: _activate_overlay(overlay, log_panel, eye, data))
    bridge.on_overlay_dismiss.connect(lambda: _dismiss_overlay(overlay, log_panel))

    bridge.on_stats.connect(lambda show: stats_bar.show_bar() if show else stats_bar.hide_bar())

    # ── Hotkey: F9 = analyze screen ───────────────────────────────────────
    import keyboard

    def on_f9():
        eye.set_state("thinking")
        t = threading.Thread(target=bridge.run_query, daemon=True)
        t.start()

    keyboard.add_hotkey(cfg.hotkey_screenshot, on_f9)

    # ── Voice listener in daemon thread ───────────────────────────────────
    ui_listener = UIVoiceListener(cfg, bridge)
    voice_thread = threading.Thread(target=ui_listener.run, daemon=True)
    voice_thread.start()

    log.info("UI started. Eye widget active. Hold F8 to speak, F9 to analyze screen.")
    sys.exit(app.exec())


def _activate_overlay(overlay, log_panel, eye, data):
    log_panel.hide_for_overlay()
    eye.set_state("thinking")
    overlay.show_annotations(data)


def _dismiss_overlay(overlay, log_panel):
    overlay.dismiss()
    log_panel.show_after_overlay()


if __name__ == "__main__":
    main()
