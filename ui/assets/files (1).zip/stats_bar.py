"""
StatsBar — glass pill bar showing CPU%, RAM%, GPU%, model name.
Hidden by default. Toggle via agent command or voice "show stats" / "hide stats".
"""

import psutil
from PyQt6.QtWidgets import QWidget, QHBoxLayout, QLabel
from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QPainter, QColor, QPainterPath, QLinearGradient, QPen

try:
    import GPUtil
    _HAS_GPU = True
except ImportError:
    _HAS_GPU = False


class StatsBar(QWidget):

    def __init__(self, screen_rect, model_name: str = "moondream:1.8b"):
        super().__init__()
        self._screen = screen_rect
        self._model = model_name
        self._visible = False

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool |
            Qt.WindowType.WindowTransparentForInput
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setFixedSize(500, 44)
        self._position()
        self._build_ui()

        # Poll metrics every 2s
        self._poll_timer = QTimer(self)
        self._poll_timer.timeout.connect(self._update_metrics)
        self._poll_timer.start(2000)

    def _position(self):
        x = self._screen.left() + (self._screen.width() - self.width()) // 2
        y = self._screen.bottom() - 60
        self.move(x, y)

    def _build_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 0, 16, 0)
        layout.setSpacing(0)

        style = """
            color: rgba(255,255,255,200);
            font-size: 12px;
            font-family: 'SF Mono', 'Consolas', monospace;
            background: transparent;
            padding: 0 10px;
        """

        self._model_lbl = self._make_label(f"⬡ {self._model}", style)
        self._sep1 = self._make_label("·", style)
        self._cpu_lbl = self._make_label("CPU –%", style)
        self._sep2 = self._make_label("·", style)
        self._ram_lbl = self._make_label("RAM –%", style)
        self._sep3 = self._make_label("·", style)
        self._gpu_lbl = self._make_label("iGPU –%", style)

        for w in [self._model_lbl, self._sep1, self._cpu_lbl,
                  self._sep2, self._ram_lbl, self._sep3, self._gpu_lbl]:
            layout.addWidget(w)

        layout.addStretch()

    def _make_label(self, text, style):
        lbl = QLabel(text)
        lbl.setStyleSheet(style)
        return lbl

    def _update_metrics(self):
        cpu = psutil.cpu_percent(interval=None)
        ram = psutil.virtual_memory().percent
        self._cpu_lbl.setText(f"CPU {cpu:.0f}%")
        self._ram_lbl.setText(f"RAM {ram:.0f}%")

        if _HAS_GPU:
            try:
                gpus = GPUtil.getGPUs()
                if gpus:
                    self._gpu_lbl.setText(f"GPU {gpus[0].load*100:.0f}%")
            except Exception:
                pass

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        path = QPainterPath()
        path.addRoundedRect(0, 0, self.width(), self.height(), 22, 22)

        painter.fillPath(path, QColor(20, 20, 30, 160))

        grad = QLinearGradient(0, 0, self.width(), 0)
        grad.setColorAt(0, QColor(60, 160, 255, 30))
        grad.setColorAt(0.5, QColor(255, 255, 255, 8))
        grad.setColorAt(1, QColor(60, 160, 255, 30))
        painter.setBrush(grad)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawPath(path)

        painter.setPen(QPen(QColor(255, 255, 255, 35), 1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(path)
        painter.end()

    def toggle(self):
        if self._visible:
            self.hide_bar()
        else:
            self.show_bar()

    def show_bar(self):
        self._visible = True
        self._update_metrics()
        self.show()
        anim = QPropertyAnimation(self, b"windowOpacity")
        anim.setDuration(300)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        anim.start()
        self._show_anim = anim

    def hide_bar(self):
        self._visible = False
        anim = QPropertyAnimation(self, b"windowOpacity")
        anim.setDuration(200)
        anim.setEndValue(0.0)
        anim.finished.connect(self.hide)
        anim.start()
        self._hide_anim = anim
