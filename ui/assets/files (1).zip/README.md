# Vision Assistant UI — Setup

## Install dependencies

```bash
pip install PyQt6 psutil
```

## Place files

```
vision_assistant/
  app.py          ← move this here (root, beside main.py)
  ui/
    eye_widget.py
    log_panel.py
    overlay.py
    stats_bar.py
  assets/
    eye.png       ← put your blue ring image here
```

## Run

```bash
py -3.11 app.py
```

## What each widget does

| Widget | Behaviour |
|--------|-----------|
| **Eye** | Floats beside cursor always. Pulses when listening, spins when thinking. |
| **Log panel** | Glass panel bottom-right. Shows your voice commands + AI responses. Scrollable. |
| **Drawing overlay** | Appears when AI returns `annotate` action. Draws arrows/circles/labels. Press Esc or F9 to dismiss. Auto-dismisses after 12s. Hides log panel while active. |
| **Stats bar** | Hidden by default. Say **"show stats"** to show, **"hide stats"** to hide. |

## Hotkeys

| Key | Action |
|-----|--------|
| F8 (hold) | Record voice command |
| F9 | Analyze screen (no voice) |
| Esc | Dismiss drawing overlay |

## Making the AI draw annotations

For the overlay to activate, your agent's response needs to include an `annotate` action.
Prompt your agent with something like:

> "show me how to drag the file" → agent returns:
```json
{
  "description": "Here's how to drag the file.",
  "actions": [{
    "action": "annotate",
    "annotations": [
      {"type": "circle", "x": 300, "y": 400, "r": 35, "label": "Pick up here"},
      {"type": "arrow", "x1": 300, "y1": 400, "x2": 700, "y2": 300, "label": "Drag to here"},
      {"type": "circle", "x": 700, "y": 300, "r": 35, "label": "Drop here"}
    ],
    "instructions": [
      "Click and hold the file in the left panel",
      "Drag it to the highlighted folder on the right",
      "Release to drop"
    ]
  }]
}
```
