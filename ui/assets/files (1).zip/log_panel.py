"""
LogPanel — iOS-inspired frosted glass panel, bottom-right of screen.
Shows AI responses as scrollable chat bubbles.
Hides when overlay mode is active.
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QScrollArea, QLabel,
    QGraphicsBlurEffect, QSizePolicy, QHBoxLayout, QPushButton
)
from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, QRect, pyqtSignal
from PyQt6.QtGui import QPainter, QColor, QPainterPath, QFont, QFontDatabase, QLinearGradient

PANEL_W = 340
PANEL_H = 420
MARGIN = 20
RADIUS = 22


class GlassBase(QWidget):
    """Reusable glass-morphism base widget (iOS material style)."""

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        path = QPainterPath()
        path.addRoundedRect(0, 0, self.width(), self.height(), RADIUS, RADIUS)

        # Base: semi-transparent white (iOS glass)
        painter.setClipPath(path)
        painter.fillPath(path, QColor(255, 255, 255, 18))

        # Subtle border highlight (top-left catch light)
        grad = QLinearGradient(0, 0, self.width(), self.height())
        grad.setColorAt(0, QColor(255, 255, 255, 55))
        grad.setColorAt(0.4, QColor(255, 255, 255, 8))
        grad.setColorAt(1, QColor(255, 255, 255, 0))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(grad)
        painter.drawPath(path)

        # Border
        from PyQt6.QtGui import QPen
        pen = QPen(QColor(255, 255, 255, 45), 1)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(path)

        painter.end()


class MessageBubble(GlassBase):
    """Single AI message bubble."""

    def __init__(self, text: str, role: str = "assistant"):
        super().__init__()
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 10, 14, 10)

        label = QLabel(text)
        label.setWordWrap(True)
        label.setStyleSheet("""
            color: rgba(255,255,255,220);
            font-size: 13px;
            font-family: 'SF Pro Text', 'Segoe UI', sans-serif;
            background: transparent;
            line-height: 1.5;
        """)
        layout.addWidget(label)

        if role == "user":
            label.setStyleSheet(label.styleSheet() + "color: rgba(140,200,255,230);")


class LogPanel(GlassBase):
    """
    Frosted glass scrollable log panel.
    Sits bottom-right, always on top, click-through except scrollable area.
    """

    def __init__(self, screen_rect):
        super().__init__()
        self._screen = screen_rect
        self._messages = []

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setFixedSize(PANEL_W, PANEL_H)

        self._position()
        self._build_ui()
        self._animate_in()
        self.show()

    def _position(self):
        x = self._screen.right() - PANEL_W - MARGIN
        y = self._screen.bottom() - PANEL_H - MARGIN
        self.move(x, y)

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Header
        header = QWidget()
        header.setFixedHeight(44)
        header.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        h_layout = QHBoxLayout(header)
        h_layout.setContentsMargins(16, 0, 16, 0)

        title = QLabel("● Vision Assistant")
        title.setStyleSheet("""
            color: rgba(255,255,255,180);
            font-size: 12px;
            font-family: 'SF Pro Text', 'Segoe UI', sans-serif;
            font-weight: 600;
            letter-spacing: 0.5px;
            background: transparent;
        """)
        h_layout.addWidget(title)
        h_layout.addStretch()

        # Thin separator line
        sep = QWidget()
        sep.setFixedHeight(1)
        sep.setStyleSheet("background: rgba(255,255,255,25);")

        # Scroll area
        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self._scroll.setStyleSheet("""
            QScrollArea {
                background: transparent;
                border: none;
            }
            QScrollBar:vertical {
                background: transparent;
                width: 4px;
                margin: 4px 2px;
            }
            QScrollBar::handle:vertical {
                background: rgba(255,255,255,60);
                border-radius: 2px;
                min-height: 20px;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)

        self._content = QWidget()
        self._content.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self._content_layout = QVBoxLayout(self._content)
        self._content_layout.setContentsMargins(10, 10, 10, 10)
        self._content_layout.setSpacing(8)
        self._content_layout.addStretch()

        self._scroll.setWidget(self._content)

        layout.addWidget(header)
        layout.addWidget(sep)
        layout.addWidget(self._scroll)

    def _animate_in(self):
        self._anim = QPropertyAnimation(self, b"windowOpacity")
        self._anim.setDuration(400)
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.start()

    def add_message(self, text: str, role: str = "assistant"):
        """Add a new message bubble to the log."""
        bubble = MessageBubble(text, role)
        # Insert before the stretch
        count = self._content_layout.count()
        self._content_layout.insertWidget(count - 1, bubble)

        # Auto-scroll to bottom
        QTimer.singleShot(50, lambda: self._scroll.verticalScrollBar().setValue(
            self._scroll.verticalScrollBar().maximum()
        ))

    def add_user_query(self, text: str):
        self.add_message(f"You: {text}", role="user")

    def add_ai_response(self, text: str):
        self.add_message(text, role="assistant")

    def hide_for_overlay(self):
        anim = QPropertyAnimation(self, b"windowOpacity")
        anim.setDuration(200)
        anim.setEndValue(0.0)
        anim.finished.connect(self.hide)
        anim.start()
        self._hide_anim = anim

    def show_after_overlay(self):
        self.show()
        self._animate_in()
