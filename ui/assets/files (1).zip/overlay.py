"""
DrawingOverlay — fullscreen transparent overlay the AI draws on.

Activated when the agent returns annotation data (arrows, circles, labels).
Deactivates after a timeout or on user dismissal (Escape / F9).

Annotation format the agent should return:
  {
    "annotations": [
      {"type": "arrow",  "x1": 100, "y1": 200, "x2": 400, "y2": 350, "label": "Drag from here"},
      {"type": "circle", "x": 500,  "y": 300,  "r": 40,   "label": "Drop here"},
      {"type": "text",   "x": 200,  "y": 100,  "text": "Step 1: Click this"},
      {"type": "box",    "x": 100,  "y": 150,  "w": 200,  "h": 80, "label": "Target area"},
    ],
    "instructions": [
      "Step 1: Pick up the file from the left panel",
      "Step 2: Drag it to the highlighted folder",
    ]
  }
"""

import math
from PyQt6.QtWidgets import QWidget, QApplication, QLabel, QVBoxLayout, QHBoxLayout
from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, QPoint, QRect, QLine
from PyQt6.QtGui import (
    QPainter, QColor, QPen, QBrush, QPainterPath,
    QFont, QLinearGradient, QRadialGradient, QPolygonF
)
from PyQt6.QtCore import QPointF

DISMISS_AFTER_MS = 12_000   # auto-dismiss after 12s
BLUE  = QColor(60, 160, 255)
GREEN = QColor(80, 220, 140)
RED   = QColor(255, 80, 80)
WHITE = QColor(255, 255, 255, 220)

ANNOTATION_COLORS = {
    "arrow":  QColor(60, 160, 255),
    "circle": QColor(80, 220, 140),
    "box":    QColor(255, 200, 60),
    "text":   QColor(255, 255, 255),
}


class InstructionsPanel(QWidget):
    """Left-side glass panel showing step-by-step instructions."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedWidth(300)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        path = QPainterPath()
        path.addRoundedRect(0, 0, self.width(), self.height(), 20, 20)

        # iOS glass: white tint + blur sim
        painter.fillPath(path, QColor(255, 255, 255, 15))

        grad = QLinearGradient(0, 0, 0, self.height())
        grad.setColorAt(0, QColor(255, 255, 255, 40))
        grad.setColorAt(1, QColor(255, 255, 255, 5))
        painter.setBrush(grad)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawPath(path)

        pen = QPen(QColor(255, 255, 255, 50), 1)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(path)
        painter.end()


class DrawingOverlay(QWidget):
    """
    Fullscreen transparent overlay. AI draws annotations on it.
    Click-through except for the instructions panel.
    """

    def __init__(self, screen_rect):
        super().__init__()
        self._screen = screen_rect
        self._annotations = []
        self._instructions = []
        self._draw_progress = 0.0   # 0→1 animated draw-in
        self._tick = 0

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setGeometry(screen_rect)

        self._build_ui()

        # Dismiss timer
        self._dismiss_timer = QTimer(self)
        self._dismiss_timer.setSingleShot(True)
        self._dismiss_timer.timeout.connect(self.dismiss)

        # Draw-in animation
        self._draw_timer = QTimer(self)
        self._draw_timer.timeout.connect(self._tick_draw)

    def _build_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(40, 60, 40, 60)
        layout.setSpacing(0)

        # Left: instructions panel
        self._instr_panel = InstructionsPanel(self)
        self._instr_layout = QVBoxLayout(self._instr_panel)
        self._instr_layout.setContentsMargins(20, 24, 20, 24)
        self._instr_layout.setSpacing(12)

        self._instr_title = QLabel("Instructions")
        self._instr_title.setStyleSheet("""
            color: rgba(255,255,255,200);
            font-size: 14px;
            font-weight: 700;
            font-family: 'SF Pro Display', 'Segoe UI', sans-serif;
            letter-spacing: 1px;
            background: transparent;
        """)
        self._instr_layout.addWidget(self._instr_title)

        self._step_labels = []
        self._instr_layout.addStretch()

        layout.addWidget(self._instr_panel)
        layout.addStretch()

        # Bottom-right dismiss hint
        hint = QLabel("Press Esc or F9 to dismiss")
        hint.setStyleSheet("""
            color: rgba(255,255,255,80);
            font-size: 11px;
            font-family: 'Segoe UI', sans-serif;
            background: transparent;
        """)
        hint.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignBottom)

    def show_annotations(self, data: dict):
        """
        data = {
          "annotations": [...],
          "instructions": [...]
        }
        """
        self._annotations = data.get("annotations", [])
        self._instructions = data.get("instructions", [])
        self._draw_progress = 0.0
        self._tick = 0

        # Rebuild instruction labels
        for lbl in self._step_labels:
            lbl.deleteLater()
        self._step_labels.clear()

        for i, step in enumerate(self._instructions):
            lbl = QLabel(f"{i+1}.  {step}")
            lbl.setWordWrap(True)
            lbl.setStyleSheet(f"""
                color: rgba(255,255,255,{180 + i * 10 if i < 4 else 210});
                font-size: 13px;
                font-family: 'SF Pro Text', 'Segoe UI', sans-serif;
                background: transparent;
                padding: 6px 0px;
            """)
            # Insert before stretch
            count = self._instr_layout.count()
            self._instr_layout.insertWidget(count - 1, lbl)
            self._step_labels.append(lbl)

        self.show()
        self._animate_in()
        self._draw_timer.start(30)
        self._dismiss_timer.start(DISMISS_AFTER_MS)

    def _animate_in(self):
        self._fade_anim = QPropertyAnimation(self, b"windowOpacity")
        self._fade_anim.setDuration(350)
        self._fade_anim.setStartValue(0.0)
        self._fade_anim.setEndValue(1.0)
        self._fade_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._fade_anim.start()

    def _tick_draw(self):
        self._tick += 1
        self._draw_progress = min(1.0, self._tick / 20.0)  # 20 ticks = ~0.6s draw-in
        self.update()
        if self._draw_progress >= 1.0:
            self._draw_timer.stop()

    def dismiss(self):
        anim = QPropertyAnimation(self, b"windowOpacity")
        anim.setDuration(300)
        anim.setEndValue(0.0)
        anim.finished.connect(self.hide)
        anim.start()
        self._out_anim = anim

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Escape, Qt.Key.Key_F9):
            self.dismiss()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Very subtle full-screen vignette (darkens edges slightly)
        vignette = QRadialGradient(self.width() / 2, self.height() / 2,
                                   max(self.width(), self.height()) * 0.7)
        vignette.setColorAt(0, QColor(0, 0, 0, 0))
        vignette.setColorAt(1, QColor(0, 0, 0, 60))
        painter.fillRect(self.rect(), vignette)

        p = self._draw_progress

        for ann in self._annotations:
            t = ann.get("type")
            color = ANNOTATION_COLORS.get(t, WHITE)

            if t == "arrow":
                self._draw_arrow(painter, ann, color, p)
            elif t == "circle":
                self._draw_circle(painter, ann, color, p)
            elif t == "box":
                self._draw_box(painter, ann, color, p)
            elif t == "text":
                self._draw_text_ann(painter, ann, p)

        painter.end()

    # ── Annotation painters ───────────────────────────────────────────────

    def _draw_arrow(self, painter, ann, color, p):
        x1, y1 = ann.get("x1", 0), ann.get("y1", 0)
        x2, y2 = ann.get("x2", 100), ann.get("y2", 100)

        # Animate: draw from start to p-fraction of end
        ex = x1 + (x2 - x1) * p
        ey = y1 + (y2 - y1) * p

        pen = QPen(color, 3)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        painter.drawLine(int(x1), int(y1), int(ex), int(ey))

        # Glow
        glow_pen = QPen(QColor(color.red(), color.green(), color.blue(), 50), 10)
        painter.setPen(glow_pen)
        painter.drawLine(int(x1), int(y1), int(ex), int(ey))

        if p >= 1.0:
            # Arrowhead
            self._draw_arrowhead(painter, x1, y1, x2, y2, color)
            # Label
            if ann.get("label"):
                self._draw_label(painter, (x1 + x2) / 2, (y1 + y2) / 2 - 16, ann["label"], color)

    def _draw_arrowhead(self, painter, x1, y1, x2, y2, color):
        angle = math.atan2(y2 - y1, x2 - x1)
        size = 14
        a1 = angle + math.pi * 0.8
        a2 = angle - math.pi * 0.8
        pts = QPolygonF([
            QPointF(x2, y2),
            QPointF(x2 + size * math.cos(a1), y2 + size * math.sin(a1)),
            QPointF(x2 + size * math.cos(a2), y2 + size * math.sin(a2)),
        ])
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(color))
        painter.drawPolygon(pts)

    def _draw_circle(self, painter, ann, color, p):
        x, y, r = ann.get("x", 0), ann.get("y", 0), ann.get("r", 40)
        r_now = r * p

        pen = QPen(color, 2.5)
        painter.setPen(pen)
        painter.setBrush(QBrush(QColor(color.red(), color.green(), color.blue(), 25)))
        painter.drawEllipse(int(x - r_now), int(y - r_now), int(r_now * 2), int(r_now * 2))

        # Glow ring
        glow = QPen(QColor(color.red(), color.green(), color.blue(), 40), 8)
        painter.setPen(glow)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawEllipse(int(x - r_now), int(y - r_now), int(r_now * 2), int(r_now * 2))

        if p >= 1.0 and ann.get("label"):
            self._draw_label(painter, x, y + r + 18, ann["label"], color)

    def _draw_box(self, painter, ann, color, p):
        x, y = ann.get("x", 0), ann.get("y", 0)
        w, h = ann.get("w", 100) * p, ann.get("h", 60) * p
        pen = QPen(color, 2)
        pen.setStyle(Qt.PenStyle.DashLine)
        painter.setPen(pen)
        painter.setBrush(QBrush(QColor(color.red(), color.green(), color.blue(), 18)))
        painter.drawRoundedRect(int(x), int(y), int(w), int(h), 6, 6)

        if p >= 1.0 and ann.get("label"):
            self._draw_label(painter, x + w / 2, y - 14, ann["label"], color)

    def _draw_text_ann(self, painter, ann, p):
        if p < 0.5:
            return
        x, y = ann.get("x", 0), ann.get("y", 0)
        text = ann.get("text", "")
        alpha = int(min(255, (p - 0.5) * 2 * 220))
        self._draw_label(painter, x, y, text, QColor(255, 255, 255, alpha), large=True)

    def _draw_label(self, painter, x, y, text, color, large=False):
        font = QFont("Segoe UI", 11 if not large else 14)
        font.setBold(True)
        painter.setFont(font)
        fm = painter.fontMetrics()
        tw = fm.horizontalAdvance(text)
        th = fm.height()
        px, py = int(x - tw / 2), int(y - th / 2)

        # Pill background
        pad = 8
        pill = QPainterPath()
        pill.addRoundedRect(px - pad, py - 4, tw + pad * 2, th + 8, 8, 8)
        painter.fillPath(pill, QColor(0, 0, 0, 140))
        painter.setPen(QPen(QColor(255, 255, 255, 180)))
        painter.drawText(px, py + fm.ascent(), text)
