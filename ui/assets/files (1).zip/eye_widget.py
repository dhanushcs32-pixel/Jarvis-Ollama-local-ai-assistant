"""
EyeWidget — always-on-top floating eye that follows the cursor.

Renders the blue ring logo from the asset file, with black made transparent.
Animates:
  - idle    : slow ring rotation
  - listening : fast pulse + glow
  - thinking  : spinning rings
  - speaking  : ripple outward
"""

import math
from pathlib import Path
from PyQt6.QtWidgets import QWidget, QApplication
from PyQt6.QtCore import Qt, QTimer, QPoint, QPropertyAnimation, QEasingCurve, pyqtProperty
from PyQt6.QtGui import QPainter, QPixmap, QColor, QRadialGradient, QPen, QBrush, QConicalGradient

ASSET = Path(__file__).parent.parent / "assets" / "eye.png"
SIZE = 72          # widget size px
OFFSET = QPoint(20, 20)   # offset from cursor so it doesn't block clicks


class EyeWidget(QWidget):
    """Frameless, transparent, always-on-top eye widget."""

    IDLE = "idle"
    LISTENING = "listening"
    THINKING = "thinking"
    SPEAKING = "speaking"

    def __init__(self):
        super().__init__()
        self._state = self.IDLE
        self._angle = 0.0          # ring rotation angle
        self._pulse = 0.0          # 0.0–1.0 pulse phase
        self._glow = 0.8           # glow intensity
        self._tick = 0

        # Try to load the eye asset
        self._pixmap = None
        if ASSET.exists():
            px = QPixmap(str(ASSET))
            if not px.isNull():
                self._pixmap = px.scaled(SIZE, SIZE, Qt.AspectRatioMode.KeepAspectRatio,
                                         Qt.TransformationMode.SmoothTransformation)

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool |
            Qt.WindowType.WindowTransparentForInput  # clicks pass through
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setFixedSize(SIZE + 20, SIZE + 20)  # extra room for glow
        self.show()

        # Cursor tracking timer
        self._track_timer = QTimer(self)
        self._track_timer.timeout.connect(self._follow_cursor)
        self._track_timer.start(16)  # ~60fps

        # Animation timer
        self._anim_timer = QTimer(self)
        self._anim_timer.timeout.connect(self._animate)
        self._anim_timer.start(33)  # ~30fps

    # ── Public state API ─────────────────────────────────────────────────

    def set_state(self, state: str):
        self._state = state
        self.update()

    # ── Internal ─────────────────────────────────────────────────────────

    def _follow_cursor(self):
        cursor = QApplication.instance().primaryScreen().availableGeometry()
        pos = self.mapFromGlobal(QPoint(0, 0))  # dummy
        global_pos = QPoint(*[c for c in [
            QApplication.instance().primaryScreen().availableVirtualGeometry().x()
        ]])
        # Get actual cursor position
        from PyQt6.QtGui import QCursor
        cp = QCursor.pos()
        self.move(cp + OFFSET)

    def _animate(self):
        self._tick += 1
        speed = {
            self.IDLE: 0.4,
            self.LISTENING: 2.5,
            self.THINKING: 3.5,
            self.SPEAKING: 1.5,
        }.get(self._state, 0.4)

        self._angle = (self._angle + speed) % 360
        self._pulse = (math.sin(self._tick * 0.15) + 1) / 2
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        cx = (self.width()) / 2
        cy = (self.height()) / 2
        r = SIZE / 2

        blue = QColor(40, 140, 255)
        bright_blue = QColor(80, 180, 255)
        glow_blue = QColor(60, 160, 255, int(60 + self._pulse * 80))

        # Outer glow
        if self._state != self.IDLE:
            grad = QRadialGradient(cx, cy, r + 14)
            grad.setColorAt(0, QColor(40, 140, 255, int(self._pulse * 90)))
            grad.setColorAt(1, QColor(0, 0, 0, 0))
            painter.setBrush(QBrush(grad))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(int(cx - r - 14), int(cy - r - 14),
                                int((r + 14) * 2), int((r + 14) * 2))

        if self._pixmap:
            # Draw asset with black → transparent compositing
            painter.save()
            painter.translate(cx, cy)
            painter.rotate(self._angle * 0.3)
            painter.translate(-cx, -cy)
            offset = (self.width() - self._pixmap.width()) // 2
            painter.drawPixmap(offset, offset, self._pixmap)
            painter.restore()
        else:
            # Fallback: draw rings manually if no asset
            self._draw_rings(painter, cx, cy, r, blue, bright_blue)

        painter.end()

    def _draw_rings(self, painter, cx, cy, r, blue, bright_blue):
        """Fallback ring drawing when asset is unavailable."""
        for i, (ring_r, width, gap_deg) in enumerate([
            (r * 0.95, 3, 45),
            (r * 0.72, 4, 60),
            (r * 0.50, 3, 30),
        ]):
            painter.save()
            painter.translate(cx, cy)
            direction = 1 if i % 2 == 0 else -1
            painter.rotate(self._angle * direction * (1 + i * 0.4))
            painter.translate(-cx, -cy)

            pen = QPen(bright_blue if i == 1 else blue, width)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            painter.setPen(pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)

            span = 360 - gap_deg
            painter.drawArc(
                int(cx - ring_r), int(cy - ring_r),
                int(ring_r * 2), int(ring_r * 2),
                int(0 * 16), int(span * 16)
            )
            painter.restore()

        # Center dot
        painter.setBrush(QBrush(bright_blue))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(int(cx - 4), int(cy - 4), 8, 8)
